

module.exports = function sayBye(name){
    console.log('byebye '+ name)
}