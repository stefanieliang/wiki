module.exports = {
    mode:'development',
    entry:"./src/index.js",
    output:{
        filename:'pack.js'
    }
}