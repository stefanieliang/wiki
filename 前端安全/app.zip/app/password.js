
// const crypto = require('crypto')

// function md5(str) {
//     const hash = crypto.createHash('md5')
//     hash.update(str)
//     return hash.digest('hex')
// }

// const sha1 = function (str) {
//     const hash = crypto.createHash('sha1')
//     hash.update(str)
//     return hash.digest('hex')
// }
// const encryptPassword = function (salt, password) {
//     return md5(salt + 'adfsf@34#$%^23!@' + password)
// }
// const psw = '111abc'
// console.log('password:', psw)
// console.log('md5:', md5('111abc'))
// console.log('sha1:', sha1(psw))
// console.log('encryptPassword:', encryptPassword('123', psw))

// module.exports = encryptPassword

const crypto = require('crypto')

const md5 = str => crypto.createHash('md5')
    .update(str).digest('hex')
const sha1 = str => crypto.createHash('sha1')
    .update(str).digest('hex')
const encryptPassword = (salt, password) => md5(salt + 'adfsf@34#$%^23!@' + password)

module.exports = encryptPassword

// console.log('md5:', md5('111111'))
// console.log('password', encryptPassword(111111))