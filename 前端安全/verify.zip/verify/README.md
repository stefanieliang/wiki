# verify
常规验证码、滑动验证码、拼图验证码、选字验证码，纯前端验证码。

<a href="http://veui.net">官网</a>

